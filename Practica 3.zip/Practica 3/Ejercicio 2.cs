﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_2_P3
{
    class Program
    {
        static void Main(string[] args)
        {
            int valor, j;
            string vvalor;
            int[,] matriz = new int[3, 4];

            Console.WriteLine("Vamos a crear una matriz\n\n");
           
            for (int i = 0; i < 4; i++)
            {
                j = i + 1;
                Console.WriteLine("Introduce el numero " + j + " de la la fila 1");
                vvalor = Console.ReadLine();
                valor = int.Parse(vvalor);
                matriz[0,i] = valor;
            }


            Console.WriteLine("\n");
            for (int i = 0; i < 4; i++)
            {
                j = i + 1;
                Console.WriteLine("Introduce el numero " + j + " de la la fila 2");
                vvalor = Console.ReadLine();
                valor = int.Parse(vvalor);
                matriz[1, i] = valor;
            }

            Console.WriteLine("\n");
            for (int i = 0; i < 4; i++)
            {
                j = i + 1;
                Console.WriteLine("Introduce el numero " + j + " de la la fila 3");
                vvalor = Console.ReadLine();
                valor = int.Parse(vvalor);
                matriz[2, i] = valor;
            }

            Console.WriteLine("\nLos numeros  de la fila 1 son: ");
            for (int i = 0; i < 4; i++)
            {
                j = i + 1;
                Console.WriteLine("Fila 1 numero" + j + ": " + matriz[0,i]);
            }

            Console.WriteLine("\nLos numeros  de la fila 3 son: ");
            for (int i = 0; i < 4; i++)
            {
                j = i + 1;
                Console.WriteLine("Fila 3 numero" + j + ": " + matriz[2, i]);
            }

            Console.WriteLine("\nLos numeros  de la columna 1 son: ");
            for (int i = 0; i < 3; i++)
            {
                j = i + 1;
                Console.WriteLine("Columna 1 numero" + j + ": " + matriz[i, 0]);
            }



            Console.ReadKey();

        }
    }
}
