﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_1_P3
{
    class Program
    {
        static void Main(string[] args)
        {
            int sueldom, sueldot, sumam, sumat, j;
            string vsueldom, vsueldot;
            int[] arreglom = new int[4];
            int[] arreglot = new int[4];

            Console.WriteLine("Vamos calcular los gastos por tanda en una empresa\n\n");
            sumam = 0;
            for (int i = 0; i <4; i++)
            {
                j = i + 1;
                Console.WriteLine("Introduce el sueldo del empleado " +j+" de la tanda de la mañana");
                vsueldom = Console.ReadLine();
                sueldom = int.Parse(vsueldom);
                arreglom[i] = sueldom;
                sumam = sumam + sueldom;
            }
            Console.WriteLine("\n");
            sumat = 0;
            for (int i = 0; i <4; i++)
            {
                j = i + 1;
                Console.WriteLine("Introduce el sueldo del empleado " + j + " de la tanda de la tarde");
                vsueldot = Console.ReadLine();
                sueldot = int.Parse(vsueldot);
                arreglom[i] = sueldot;
                sumat = sumat + sueldot;
            }
           
           
                Console.WriteLine("\nLa suma de gastos de empleados de la mañana es: "+sumam+"\nLasuma de gastos de los empleados de la tarde es: "+sumat);
                Console.ReadKey();

        }
    }
}
