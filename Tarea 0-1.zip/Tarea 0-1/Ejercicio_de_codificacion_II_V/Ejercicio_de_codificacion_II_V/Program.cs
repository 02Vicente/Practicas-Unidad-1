﻿using System;

namespace Ejercicio_de_codificacion_II_V
{
    class Program
    {
        static void Main(string[] args)
        {
            double centimetros, pulgadas;

            Console.WriteLine("===============>>> Programa convertir de centimetros a pulgadas <<<=================");

            Console.WriteLine("\nIngrese el primer valor en centimetros: ");
            centimetros = double.Parse(Console.ReadLine());

            pulgadas = centimetros / 2.54;
            
            if (centimetros == 1) {
                Console.WriteLine("\n" + centimetros + " centimetro en pulgadas es " + pulgadas);
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("\n" + centimetros + " centimetros en pulgadas es " + pulgadas);
                Console.ReadKey();
            }
            
        }
    } 
}
