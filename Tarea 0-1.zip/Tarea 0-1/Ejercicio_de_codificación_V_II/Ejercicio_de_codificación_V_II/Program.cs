﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_de_codificación_V_II
{
    class Program
    {
        static void Main(string[] args)
        {
            string p = "";

            do
            {
                Console.WriteLine("+++++++++++++++++++++ MENU DE OPCIONES ++++++++++++++++++++++");
                Console.WriteLine("TABLA DE MULTIPLICAR [T]");
                Console.WriteLine("CALCULAR PROMEDIO [P]");
                Console.WriteLine("SALIR [S]");
                Console.WriteLine("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                Console.WriteLine("ESCRIBA UNA OPCION");
                p = Console.ReadLine();
                switch (p)
                {
                    case "t":
                    case "T":
                        Console.WriteLine("\nNumero de la tabla :");
                        int numero = int.Parse(Console.ReadLine());

                        for (int i = 0; i <= 12; i++)
                        {
                            Console.WriteLine(numero + "X" + i + "=" + (numero*i));
                        }
                        Console.ReadKey();
                        Console.Clear();
                        break;

                    case "p":
                    case "P":
                        Console.WriteLine("\nPromedio de notas");
                        Console.WriteLine("Calificacion 1:");
                        int nota_1 = int.Parse(Console.ReadLine());

                        Console.WriteLine("Calificacion 2:");
                        int nota_2 = int.Parse(Console.ReadLine());

                        Console.WriteLine("Calificacion 3:");
                        int nota_3 = int.Parse(Console.ReadLine());

                        Console.WriteLine("Calificacion 4:");
                        int nota_4 = int.Parse(Console.ReadLine());

                        int resultado = (nota_1 + nota_2 + nota_3 + nota_4) / 4;
                        Console.WriteLine("Promedio : ", resultado);

                        break;
                    default:
                        Console.WriteLine("Adios...");
                        p = "s";
                        break;
                }

            } while (p != "s" && p != "S");

            Console.ReadKey();
        }
    }
}
