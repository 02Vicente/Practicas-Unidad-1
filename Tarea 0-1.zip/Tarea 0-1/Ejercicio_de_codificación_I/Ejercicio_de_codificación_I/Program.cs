﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_de_codificación_I
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();

            Console.WriteLine("===============>>> INFORMACION PERSONAL <<<=================");
            Console.WriteLine("Nombre: Vicente");
            Console.WriteLine("Apellido: Luna");
            Console.WriteLine("Apodo: Vicente");
            Console.WriteLine("Fecha de Nacimiento: 27/03/1996");
            Console.WriteLine("Telefono: 803-231-0513");
            Console.WriteLine("Celular: 829-303-6935");
            Console.WriteLine("Pais: Republica Dominicana");
            Console.WriteLine("Ciudad: Santo Domingo");
            Console.WriteLine("Direccion: C/Sinai #7");
            Console.WriteLine("Lugar de Trabajo: Senado");
            Console.WriteLine("Sueldo: 25,300");
            Console.ReadKey();
        }
    }
}
