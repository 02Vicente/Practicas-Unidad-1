﻿using System;

namespace Ejercicio_de_codificacion_III_II
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("===============>>> CALCULO DE PROMEDIO <<<=================");
            double nota1 = 0, nota2 = 0, nota3 = 0, nota4 = 0, promedio = 0;
            string status;
            Console.WriteLine("\nIngrese la nota 1: ");
            nota1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la nota 2: ");
            nota2 = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la nota 3: ");
            nota3 = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la nota 4: ");
            nota4 = double.Parse(Console.ReadLine());

            promedio = (nota1 + nota2 + nota3 + nota4) / 4;
            status = "Aun nada";
            
            if (promedio > 90 && promedio <= 100)
            {
                status = "Excelente";
            }
            else if (promedio >= 85 && promedio < 90)
            {
                status = "Sobresaliente";
            }
            else if (promedio >= 75 && promedio < 85)
            {
                status = "Muy bueno";
            }
            else if (promedio >= 65 && promedio < 75)
            {
                status = "Aprobado";
            }
            else if (promedio < 65)
            {
                status = "Reprobado";
            }

            Console.WriteLine("\nEl Promedio es: " + promedio + " " + status);
            Console.ReadKey();
        }
    }
}
