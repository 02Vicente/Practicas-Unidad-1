﻿using System;

namespace Ejercicio_de_codificacion_II_IV
{
    class Program
    {
        static void Main(string[] args)
        {
            double SB, SN, TH, HT, DD;

            Console.WriteLine("===============>>> CALCULO DE SUELDO <<<=================");
            Console.WriteLine("\nIngrese la cantidad de horas trabajadas del Empleado: ");
            HT = int.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la tarifa de las horas trabajadas del Empleado: ");
            TH = int.Parse(Console.ReadLine());

            SB = HT * TH;
            DD = SB * 0.1;
            SN = SB - DD;

            Console.WriteLine("SUELDO BRUTO: RD$" + SB + "\nDESCUENTOS: RD$" + DD + "\nSUELDO NETO: RD$" + SN);
            Console.ReadKey();
        }
    }
}
