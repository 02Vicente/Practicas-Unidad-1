﻿using System;

namespace Ejercicio_de_codificacion_II_VI
{
    class Program
    {
        static void Main(string[] args)
        {
            double m, i, t, c, ip, r;
            Console.WriteLine("===============>>> PROGRAMA DE SUMAR 2 NUMEROS <<<=================");

            Console.WriteLine("\nIngrese el monto del prestamo:");
            m = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese el interes:");
            i = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese el tiempo en meses:");
            t = double.Parse(Console.ReadLine());

            ip = i / 100;
            c = ((m * ip) / t) + (m / t);
            r = Math.Round(c, 2);

            Console.WriteLine("\nEl monto es: RD$" + m);
            Console.WriteLine("El interes es : %" + i);
            Console.WriteLine("El tiempo en meses es: " +t+" meses");
            Console.WriteLine("La cuota mensual es: "+ r);
            Console.ReadKey();
        }
    }
}
