﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_de_codificación_IV_V
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("===============>>> TABLAS DE MULTIPLICAR <<<=================");
            for (int i = 1; i <= 12; i++)
            {
                Console.WriteLine("\nTabla de multiplicar del {0}", i);
                Console.WriteLine("------------------------------");
                for (int j = 1; j <= 12; j++)
                {
                    Console.WriteLine("{0}X{1} = {2}", i, j, (i * j));
                }
            }

            Console.ReadKey();
        }
    }
}
