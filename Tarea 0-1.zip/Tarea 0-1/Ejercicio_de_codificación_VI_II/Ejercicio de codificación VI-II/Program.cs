﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_de_codificación_VI_II
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("===============>>> SUMA DE ELEMENTOS DE UN VECTOR <<<=================\n");
            int[] vector = new int[4];
            int r, k, l=0;

            for (int i = 0; i <= 4; i++)
            {
                if (i == 4)
                {
                    break;
                }
                r = i + 1;
                
                Console.WriteLine("Ingrese en valor de la  posicion " + r+": ");
                vector[i] = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("");
            for (int j = 0; j < vector.Length; j++)
            {
                k = j + 1;
                Console.WriteLine("Valor de la posicion " + k + " = " + vector[j]);
                l = l + vector[j];
            }

            Console.WriteLine("");
            Console.WriteLine("Sumatoria Vector = "+l);
            Console.ReadKey();
        }
    }
}
