﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_de_codificación_IV_III
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("===============>>> NUMEROS DEL 3 AL 20 CON SU CUBO<<<=================");

            for (int i = 3; i <= 20; i++)
            {               
                Console.WriteLine("{0}^{1} = {2:N0}", 3, i, Math.Pow(3, i));
            }

            Console.ReadKey();
        }
    }
}
