﻿using System;

namespace Ejercicio_de_codificacion_II_I
{
    class Program
    {
        static void Main(string[] args)
        {
            string nombre;
            Console.WriteLine("===============>>> PROGRAMA SALUDO <<<=================");

            Console.WriteLine("\nIngrese su nombre: ");
            nombre = Console.ReadLine();

            Console.WriteLine("\nHola "+nombre);
            Console.ReadKey();
        }


    }
}
