﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EstructuraRepetitivaDoWhile5
{
    class Program
    {
        static void Main(string[] args)
        {
            int cuenta, cantidad, i;
            double saldo, suma;
            string vcuenta, vcantidad;

            Console.WriteLine("Evaluar cuentas de banco\n\nIntroduce la cantidad de cuentas a evaluar: ");
            vcantidad = Console.ReadLine();
            cantidad= int.Parse(vcantidad);

            suma = 0;
            cuenta = 0;
            i=0;
            Console.WriteLine("\n");
            do{
                    Console.Write("Ingrese número de cuenta:");
                    vcuenta = Console.ReadLine();
                    cuenta = int.Parse(vcuenta);
                    if (cuenta >= 0)
                    {
                        Console.Write("Ingrese saldo:");
                        vcuenta = Console.ReadLine();
                        saldo = float.Parse(vcuenta);
                        if (saldo > 0)
                        {
                            Console.WriteLine("Saldo Acreedor\n");
                            suma = suma + saldo;
                        }
                        else
                        {
                            if (saldo < 0)
                            {
                                Console.WriteLine("Saldo Deudor\n");
                            }
                            else
                            {
                                Console.WriteLine("Saldo Nulo\n");
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("\nEl numero de cuenta especificado no es admitido\n");
                        Console.ReadKey();
                        Environment.Exit(1);

                    }
            
               i= i+1;
            }while(i <cantidad); 
            
            Console.Write("Total de saldos Acreedores:"+ suma);           
            Console.ReadKey();
        }
    }
}