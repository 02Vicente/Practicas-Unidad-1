﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_3_P1
{
    class Program
    {
        static void Main(string[] args)
        {
            double sueldo1, sueldo2, suma, resultado;
            string vsueldo1;

            Console.WriteLine("Vamos a calcular el valor de un aumento de 40% en el sueldo de un empleado\n\nIntroduzca el sueldo actual:");
            vsueldo1 = Console.ReadLine();
            sueldo1 = int.Parse(vsueldo1);

            sueldo2 = sueldo1 * 0.4;
            suma = sueldo1 + sueldo2;

            resultado = Math.Round(suma, 2);
            Console.WriteLine("\nEl nuevo sueldo es: "+resultado);

            Console.ReadKey();

        }
    }
}
