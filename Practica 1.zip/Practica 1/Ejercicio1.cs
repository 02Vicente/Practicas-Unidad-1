﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, perimetro;
            string num;

            Console.WriteLine("Escribe la longitud de un lado: ");
            num = Console.ReadLine();
            num1 = int.Parse(num);
            perimetro = num1 * 4;

            Console.WriteLine("El Perimetro de este cuadrado es " + perimetro);
            Console.ReadKey();
              }
    }
}
