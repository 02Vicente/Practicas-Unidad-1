﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            int mujeres, hombres, total, resultadom, resultadoh;
            double pmujeres, phombres;
            string vmujeres, vhombres;

            Console.WriteLine("Vamos a calcular el porcentaje de estudiantes masculinos y femeninos\n\nIntroduzca la cantidad de mujeres: ");
            vmujeres = Console.ReadLine();
            mujeres = int.Parse(vmujeres);
            Console.WriteLine("Introduzca la cantidad de hombres: ");
            vhombres = Console.ReadLine();
            hombres = int.Parse(vhombres);
            total = hombres + mujeres;

            phombres = (hombres * 100) / total;
            pmujeres = (mujeres * 100) / total;

            Console.WriteLine("\nLa cantidad total es "+total+", hay "+mujeres+" Mujeres y "+hombres+" hombres lo que equivale a un "+pmujeres+"% de mujeres y un "+phombres+"% de hombres");
            Console.ReadKey();

        }
    }
}
